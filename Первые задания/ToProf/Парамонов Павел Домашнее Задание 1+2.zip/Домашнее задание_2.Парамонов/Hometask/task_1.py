

import numpy as np
import pandas as pd




data = pd.read_pickle('./var26.pkl')
print(data)